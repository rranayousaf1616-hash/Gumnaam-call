# Gumnaam Call - Setup

## 1. Apne computer par chalao
    npm install
    npm start
Browser mein http://localhost:3000 kholo. Do tabs (ya do phone) mein kholo, dono "Baat Shuru Karo" dabao, aur aapas mein connect ho jayenge.
(localhost par mic chalta hai. Internet par HTTPS zaroori hai, jo free hosts khud dete hain.)

## 2. Internet par publish karo (free plan wale host)
Render, Railway, Fly.io jaise host par yeh folder deploy karo.
- Build command: npm install
- Start command: npm start
- Free plan ki shartein khud check kar lena. Kuch free plans par server idle hone par so jata hai.

## 3. TURN (alag-alag network par call ke liye)
Metered Open Relay ya Turnix par free account banao, phir host ke Environment Variables mein daalo:
    TURN_URL   = turn:server-address:443,turns:server-address:443?transport=tcp
    TURN_USER  = aapka-username
    TURN_PASS  = aapka-password
Bina TURN ke bhi zyada tar calls chalengi, par kuch networks par connect nahi hoga.

## 4. Publish se pehle
- Terms aur Privacy page banao.
- Reports server ke log mein aate hain. Unhe dekhte raho.
- Anonymous calls mein misuse hota hai, isliye moderation ka plan rakho.
